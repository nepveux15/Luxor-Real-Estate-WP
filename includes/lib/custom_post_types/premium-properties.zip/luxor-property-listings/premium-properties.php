<?php 

/*
Plugin Name: Properties Post Type for Luxor WordPress Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type for property posts.
Version: 1.0.6
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

//Actions
add_action('init', 'pm_ln_create_properties');
add_action('init', 'pm_ln_properties_categories');
add_action('init', 'pm_ln_properties_sale_types');
add_action('init', 'pm_ln_properties_payment_terms');
add_action('init', 'pm_ln_properties_status_types');
add_action('init', 'pm_ln_properties_amenities');

add_action('admin_enqueue_scripts', 'pm_load_properties_admin_scripts');
add_action('wp_enqueue_scripts', 'pm_load_properties_front_scripts');

add_action('admin_init', 'pm_ln_properties_admin');

add_action('save_post', 'pm_ln_add_properties_fields', 10, 2); //SAVE FIELDS

add_action('quick_edit_custom_box', 'pm_ln_quick_edit_description_field', 10, 3 );

add_action( "edited_propertysaletypes", 'pm_ln_save_inline_description' );

add_action('admin_menu', 'pm_ln_add_property_settings' );// ADD SETTINGS PAGE

//Translation support
add_action('plugins_loaded', 'pm_ln_premium_properties_load_textdomain');

//Filters
add_filter( "manage_edit-propertysaletypes_columns", function( $columns ) {
    $columns['_description'] = '';
    return $columns;
});

add_filter( "manage_propertysaletypes_custom_column", function( $e, $column, $term_id ) {
    if ( $column === '_description' ) return '';
}, 10, 3 );

add_filter( "get_user_option_manageedit-propertysaletypescolumnshidden", function( $r ) {
    $r[] = '_description';
    return $r;
});

/**** FUNCTIONS **********************************************************************************************/



//Add sub menus
function pm_ln_add_property_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_properties', esc_attr__('Property Settings', 'premiumproperties'),  esc_attr__('Property Settings', 'premiumproperties'), 'manage_options', 'property_settings',  'pm_ln_property_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}

//Settings page
function pm_ln_property_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_property_settings_update'])) {
		
		update_option('pm_set_featured_property_meta', (string)$_POST["pm_set_featured_property_meta"]);
		update_option('pm_properties_slug_name', sanitize_text_field($_POST["pm_properties_slug_name"]));
		update_option('pm_properties_display_price_meta', (string)$_POST["pm_properties_display_price_meta"]);
		update_option('pm_properties_display_assign_to_agent_meta', (string)$_POST["pm_properties_display_assign_to_agent_meta"]);
		
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'premiumproperties').'</h4></div>';
		
	}//end of save data
	
	$pm_set_featured_property_meta = get_option('pm_set_featured_property_meta');
	$pm_properties_slug_name = get_option('pm_properties_slug_name');
	$pm_properties_display_price_meta = get_option('pm_properties_display_price_meta');
	$pm_properties_display_assign_to_agent_meta = get_option('pm_properties_display_assign_to_agent_meta');
	
	?>
	
	<div class="wrap">
    
		<?php screen_icon(); ?>
        
		<h2><?php esc_attr_e('Property Settings', 'premiumproperties') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Properties Post Type plug-in below:', 'premiumproperties') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_property_settings_update" id="pm_property_settings_update" value="true" />
            
            
            <label for="pm_properties_slug_name"><?php esc_attr_e('Properties post type slug name', 'premiumproperties') ?>:</label>
            
            <br><br>
            
            <input type="text" name="pm_properties_slug_name" id="pm_properties_slug_name" value="<?php echo $pm_properties_slug_name !== '' ? esc_attr($pm_properties_slug_name) : 'property-post' ?>" />
            
            <br><br>
			
            <label for="pm_set_featured_property_meta"><?php esc_attr_e('Enable "Featured Property" option on front-end?', 'premiumproperties') ?></label>
            
            <br><br>
            	
			<select name="pm_set_featured_property_meta">
            	
                <?php if($pm_set_featured_property_meta !== '') { ?>
                
                	<option value="off" <?php selected(esc_attr($pm_set_featured_property_meta), 'off') ?>> <?php esc_attr_e('NO', 'premiumproperties'); ?> </option>
                	<option value="on" <?php selected(esc_attr($pm_set_featured_property_meta), 'on') ?>> <?php esc_attr_e('YES', 'premiumproperties'); ?> </option>
                
                <?php } else { ?>
                
                	<option value="off"> <?php esc_attr_e('NO', 'premiumproperties'); ?> </option>
                	<option value="on"> <?php esc_attr_e('YES', 'premiumproperties'); ?> </option>
                
                <?php } ?>                
                
            </select>
			
            <br><br>   
            
            <label for="pm_properties_display_price_meta"><?php esc_attr_e('Display property prices to members only?', 'premiumproperties') ?></label>
            
            <br><br>
            	
			<select name="pm_properties_display_price_meta">
            	
                <?php if($pm_properties_display_price_meta !== '') { ?>
                
                	<option value="yes" <?php selected(esc_attr($pm_properties_display_price_meta), 'yes') ?>> <?php esc_attr_e('YES', 'premiumproperties'); ?> </option>
                	<option value="no" <?php selected(esc_attr($pm_properties_display_price_meta), 'no') ?>> <?php esc_attr_e('NO', 'premiumproperties'); ?> </option>
                	
                
                <?php } else { ?>
                
                	<option value="yes"> <?php esc_attr_e('YES', 'premiumproperties'); ?> </option>
                	<option value="no"> <?php esc_attr_e('NO', 'premiumproperties'); ?> </option>
                
                <?php } ?>                
                
            </select>   
            
            <br><br> 
            
            <label for="pm_properties_display_assign_to_agent_meta"><?php esc_attr_e('Display "Assign to Agent" option on property submission template?', 'premiumproperties') ?></label>
            
            <br><br>
            
            <select name="pm_properties_display_assign_to_agent_meta">
            	
                <?php if($pm_properties_display_assign_to_agent_meta !== '') { ?>
                
                	
                	<option value="no" <?php selected(esc_attr($pm_properties_display_assign_to_agent_meta), 'no') ?>> <?php esc_attr_e('NO', 'premiumproperties'); ?> </option>
                    <option value="yes" <?php selected(esc_attr($pm_properties_display_assign_to_agent_meta), 'yes') ?>> <?php esc_attr_e('YES', 'premiumproperties'); ?> </option>
                	
                
                <?php } else { ?>
                                	
                	<option value="no"> <?php esc_attr_e('NO', 'premiumproperties'); ?> </option>
                    <option value="yes"> <?php esc_attr_e('YES', 'premiumproperties'); ?> </option>
                
                <?php } ?>                
                
            </select>   
            
            <br><br> 
            
            
			<div>
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'premiumproperties'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}



function pm_ln_premium_properties_load_textdomain() { 
	load_plugin_textdomain( 'premiumproperties', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 



function pm_ln_quick_edit_description_field($column, $screen, $tax = '') { 
	
	if ( $screen !== 'edit-tags' ) return;
    $taxonomy = get_taxonomy( $tax );
    if ( ! current_user_can( $taxonomy->cap->edit_terms ) ) return;
    //global $the_target_tax;
    if ( $tax !== 'propertysaletypes' || $column !== '_description' ) return;
    ?>
    <fieldset>
        <div class="inline-edit-col">
        <label>
            <span class="title"><?php _e('Description', 'premiumproperties'); ?></span>
            <span class="input-text-wrap">
            <textarea id="inline-desc" name="description" rows="3" class="ptitle"></textarea>
            </span>
        </label>
        </div>
    </fieldset>
    <script>
    jQuery('#the-list').on('click', 'a.editinline', function(){
        var now = jQuery(this).closest('tr').find('td.column-description').text();
        jQuery('#inline-desc').text( now );
    });
    </script>
    <?php
	
} 

function pm_ln_create_properties() {
	
	$pm_properties_slug_name = get_option('pm_properties_slug_name');
	
    register_post_type('post_properties',
		array(
			'labels' => array(
				'name' => __( 'Properties', 'premiumproperties' ),
				'singular_name' => __( 'Property', 'premiumproperties' ),
				'add_new' => __( 'Add New Property', 'premiumproperties' ),
				'add_new_item' => __( 'Add New Property', 'premiumproperties' ),
				'edit' => __( 'Edit', 'premiumproperties' ),
				'edit_item' => __( 'Edit Property', 'premiumproperties' ),
				'new_item' => __( 'New Property', 'premiumproperties' ),
				'view' => __( 'View', 'premiumproperties' ),
				'view_item' => __( 'View Property', 'premiumproperties' ),
				'search_items' => __( 'Search Property', 'premiumproperties' ),
				'not_found' => __( 'No Properties found', 'premiumproperties' ),
				'not_found_in_trash' => __( 'No Properties found in Trash', 'premiumproperties' ),
				'parent' => __( 'Parent Property', 'premiumproperties' )
			),
			'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => __( 'Easily lets you add new property items.', 'premiumproperties' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => !empty($pm_properties_slug_name) ? $pm_properties_slug_name : 'property-post'),
			//'taxonomies' => array('category', 'post_tag')
		)
	); 
	flush_rewrite_rules();
	
}

function pm_ln_properties_categories() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Property Categories', 'premiumproperties' ),
		'singular_name' => __( 'Property Categories', 'premiumproperties' ),
		'search_items' =>  __( 'Search Property Categories', 'premiumproperties' ),
		'popular_items' => __( 'Popular Property Categories', 'premiumproperties' ),
		'all_items' => __( 'All Property Categories', 'premiumproperties' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Property Category', 'premiumproperties' ),
		'update_item' => __( 'Update Property Category', 'premiumproperties' ),
		'add_new_item' => __( 'Add Property Category', 'premiumproperties' ),
		'new_item_name' => __( 'New Property Category Name', 'premiumproperties' ),
		'separate_items_with_commas' => __( 'Separate Property Categories with commas', 'premiumproperties' ),
		'add_or_remove_items' => __( 'Add or remove Property Categories', 'premiumproperties' ),
		'choose_from_most_used' => __( 'Choose from the most used Property Categories', 'premiumproperties' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'propertycats', 'post_properties', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'property-category' ), // changes name in permalink structure
    ));
	flush_rewrite_rules();
	
}

function pm_ln_properties_sale_types() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Property Sale Types', 'premiumproperties' ),
		'singular_name' => __( 'Property Sale Types', 'premiumproperties' ),
		'search_items' =>  __( 'Search Property Sale Types', 'premiumproperties' ),
		'popular_items' => __( 'Popular Property Sale Types', 'premiumproperties' ),
		'all_items' => __( 'All Property Sale Types', 'premiumproperties' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Property Sale Type', 'premiumproperties' ),
		'update_item' => __( 'Update Property Sale Type', 'premiumproperties' ),
		'add_new_item' => __( 'Add Property Sale Type', 'premiumproperties' ),
		'new_item_name' => __( 'New Property Sale Type Name', 'premiumproperties' ),
		'separate_items_with_commas' => __( 'Separate Property Sale Types with commas', 'premiumproperties' ),
		'add_or_remove_items' => __( 'Add or remove Property Sale Types', 'premiumproperties' ),
		'choose_from_most_used' => __( 'Choose from the most used Property Sale Types', 'premiumproperties' ),
		'not_found' => __( 'No Property Sale Types found', 'premiumproperties' ),
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'propertysaletypes', 'post_properties', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => false,
		'rewrite' => array( 'slug' => 'property-sale-types' ), // changes name in permalink structure
    ));
	flush_rewrite_rules();
	
}

function pm_ln_properties_status_types() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Property Status Types', 'premiumproperties' ),
		'singular_name' => __( 'Property Status Types', 'premiumproperties' ),
		'search_items' =>  __( 'Search Property Status Types', 'premiumproperties' ),
		'popular_items' => __( 'Popular Property Status Types', 'premiumproperties' ),
		'all_items' => __( 'All Property Status Types', 'premiumproperties' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Property Status Type', 'premiumproperties' ),
		'update_item' => __( 'Update Property Status Type', 'premiumproperties' ),
		'add_new_item' => __( 'Add Property Status Type', 'premiumproperties' ),
		'new_item_name' => __( 'New Property Status Type Name', 'premiumproperties' ),
		'separate_items_with_commas' => __( 'Separate Property Status Types with commas', 'premiumproperties' ),
		'add_or_remove_items' => __( 'Add or remove Property Status Types', 'premiumproperties' ),
		'choose_from_most_used' => __( 'Choose from the most used Property Status Types', 'premiumproperties' ),
		'not_found' => __( 'No Property Status Types found', 'premiumproperties' ),
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'propertystatustypes', 'post_properties', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => false,
		'rewrite' => array( 'slug' => 'property-status-types' ), // changes name in permalink structure
    ));
	flush_rewrite_rules();
}

function pm_ln_properties_amenities() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Property Amenities', 'premiumproperties' ),
		'singular_name' => __( 'Property Amenities', 'premiumproperties' ),
		'search_items' =>  __( 'Search Property Amenities', 'premiumproperties' ),
		'popular_items' => __( 'Popular Property Amenities', 'premiumproperties' ),
		'all_items' => __( 'All Property Amenities', 'premiumproperties' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Property Amenity', 'premiumproperties' ),
		'update_item' => __( 'Update Property Amenity', 'premiumproperties' ),
		'add_new_item' => __( 'Add Property Amenity', 'premiumproperties' ),
		'new_item_name' => __( 'New Property Amenity Name', 'premiumproperties' ),
		'separate_items_with_commas' => __( 'Separate Property Amenities with commas', 'premiumproperties' ),
		'add_or_remove_items' => __( 'Add or remove Property Amenities', 'premiumproperties' ),
		'choose_from_most_used' => __( 'Choose from the most used Property Amenities', 'premiumproperties' ),
		'not_found' => __( 'No Property Amenities found', 'premiumproperties' ),
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'propertyamenitiestypes', 'post_properties', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => false,
		'rewrite' => array( 'slug' => 'property-amenity' ), // changes name in permalink structure
    ));
	flush_rewrite_rules();
}




function pm_ln_properties_payment_terms() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Property Payment Terms', 'premiumproperties' ),
		'singular_name' => __( 'Property Payment Terms', 'premiumproperties' ),
		'search_items' =>  __( 'Search Property Payment Terms', 'premiumproperties' ),
		'popular_items' => __( 'Popular Property Payment Terms', 'premiumproperties' ),
		'all_items' => __( 'All Property Payment Terms', 'premiumproperties' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Property Payment Terms', 'premiumproperties' ),
		'update_item' => __( 'Update Property Payment Terms', 'premiumproperties' ),
		'add_new_item' => __( 'Add Property Payment Terms', 'premiumproperties' ),
		'new_item_name' => __( 'New Property Payment Terms Name', 'premiumproperties' ),
		'separate_items_with_commas' => __( 'Separate Property Payment Terms with commas', 'premiumproperties' ),
		'add_or_remove_items' => __( 'Add or remove Property Payment Terms', 'premiumproperties' ),
		'choose_from_most_used' => __( 'Choose from the most used Property Payment Terms', 'premiumproperties' ),
		'not_found' => __( 'No Property Payment Terms found', 'premiumproperties' ),
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'propertypaymentterms', 'post_properties', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => false,
		'rewrite' => array( 'slug' => 'property-payment-terms' ), // changes name in permalink structure
    ));
	flush_rewrite_rules();
}



function pm_load_properties_admin_scripts() {

	wp_enqueue_script( 'pulsar-premium-properties', plugin_dir_url(__FILE__) . 'js/pm-premium-properties.js', array(), '1.0', true );
	wp_enqueue_style( 'pulsar-premium-properties', plugin_dir_url(__FILE__) . 'css/pm-premium-properties.css' );
	
}

function pm_load_properties_front_scripts() {

	wp_enqueue_script( 'pulsar-premium-properties', plugin_dir_url(__FILE__) . 'js/pm-premium-properties-front.js', array(), '1.0', true );
	//wp_enqueue_style( 'pulsar-premium-properties', plugin_dir_url(__FILE__) . 'css/pm-premium-properties.css' );
	
}



function pm_ln_properties_admin() {
	
	//Header Image
	add_meta_box( 
		'pm_header_image_meta', //ID
		__('Page Header Image','premiumproperties'),  //label
		'pm_properties_header_image_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Thumbnail image
	add_meta_box( 
		'pm_properties_thumb_image_meta', //ID
		__('Property Thumbnail Image','premiumproperties'),  //label
		'pm_properties_thumb_image_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Property image
	add_meta_box( 
		'pm_properties_image_meta', //ID
		__('Property Image','premiumproperties'),  //label
		'pm_properties_image_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Sale Type
	add_meta_box( 
		'pm_properties_type_meta', //ID
		__('Sale Type','premiumproperties'),  //label
		'pm_properties_type_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Property Price
	add_meta_box( 
		'pm_properties_price_meta', //ID
		__('Property Price','premiumproperties'),  //label
		'pm_properties_price_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Property Size
	add_meta_box( 
		'pm_properties_size_meta', //ID
		__('Property Size','premiumproperties'),  //label
		'pm_properties_size_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Property status
	add_meta_box( 
		'pm_properties_status_meta', //ID
		__('Property Status','premiumproperties'), //label
		'pm_properties_status_meta_function', //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	
	//Property Address
	add_meta_box( 
		'pm_properties_address_meta', //ID
		__('Property Address','premiumproperties'),  //label
		'pm_properties_address_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
		
	//Gallery Assignment
	add_meta_box( 
		'pm_properties_featured_meta', //ID
		__('Featured Property','premiumproperties'),  //label
		'pm_properties_featured_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
		
	//Property slides
	add_meta_box( 
		'pm_properties_slides', //ID
		__('Carousel Options','premiumproperties'),  //label
		'pm_properties_slides_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Video options
	add_meta_box( 
		'pm_properties_video_options', //ID
		__('Video Options','premiumproperties'),  //label
		'pm_properties_video_options_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Property Summary
	add_meta_box( 
		'pm_properties_summary_meta', //ID
		__('Property Information','premiumproperties'),  //label
		'pm_properties_summary_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Property Amenities
	add_meta_box( 
		'pm_properties_meta_amenities', //ID
		__('Property Amenities','premiumproperties'),  //label
		'pm_properties_amenities_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Assign to Agent from Database
	add_meta_box( 
		'pm_assign_agent_meta', //ID
		__('Assign to Agent?','premiumproperties'),  //label
		'pm_assign_agent_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
	//Share
	add_meta_box( 
		'pm_page_print_share_meta', //ID
		__('Enable Share options?','premiumproperties'),  //label
		'pm_share_meta_function' , //function
		'post_properties', //Post type
		'normal', 
		'high' 
	);
	
}


function pm_properties_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_header_image_meta = get_post_meta( $post->ID, 'pm_header_image_meta', true );
	//echo $post->ID . $pm_woocom_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px or 1920x800px for parallax mode','premiumproperties'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_header_image_meta); ?>" name="pm_header_image_meta" id="pm-properties-header-img-uploader-field" class="pm-admin-properties-header-upload-field" />
		<input id="pm_properties_header_upload_image_button" type="button" value="<?php _e('Media Library Image', 'premiumproperties'); ?>" class="button button-primary button-large" />
        <div class="pm-properties-header-image-preview"></div>
        
        <?php if($pm_header_image_meta) : ?>
        	<input id="remove_properties_header_img_button" type="button" value="<?php _e('Remove Image', 'premiumproperties'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}


function pm_properties_slides_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_slides = get_post_meta( $post->ID, 'pm_properties_slides', true ); //ARRAY VALUE
	$pm_enable_slider_system = get_post_meta( $post->ID, 'pm_enable_slider_system', true );
	$pm_enable_fullscreen_mode = get_post_meta( $post->ID, 'pm_enable_fullscreen_mode', true );
	
	//print_r($pm_properties_slides);
	
	?>
    
    	<p><?php _e('Enable Carousel?', 'premiumproperties') ?></p>
        
        <select id="pm_enable_slider_system" name="pm_enable_slider_system" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_enable_slider_system, 'no' ); ?>><?php _e('No', 'premiumproperties') ?></option>
            <option value="yes" <?php selected( $pm_enable_slider_system, 'yes' ); ?>><?php _e('Yes', 'premiumproperties') ?></option>
        </select>
        
        
        <?php if($pm_enable_slider_system === 'yes') { ?>
        	<div class="pm-featured-properties-settings-container visible" id="pm_featured_properties_settings_container">
        <?php } else { ?>
        	<div class="pm-featured-properties-settings-container hidden" id="pm_featured_properties_settings_container">
        <?php } ?>
                
            <p><?php _e('Add or remove slides', 'premiumproperties') ?></p>
                    
            <div id="pm-featured-properties-images-container">
            
                <?php 
                
                    $counter = 0;
                
                    if(is_array($pm_properties_slides)){
                        
                        foreach($pm_properties_slides as $val) {
                        
                            echo '<div class="pm-slider-system-field-container" id="pm_slider_system_field_container_'.$counter.'">';
							echo '<input type="text" value="'.esc_html($val).'" name="pm_slider_system_post[]" id="pm_slider_system_post_'.$counter.'" class="pm-slider-system-upload-field" />';
                            echo '<input type="button" value="'.__('Media Library Image', 'premiumproperties').'" class="button-secondary slider_system_upload_image_button" id="pm_slider_system_post_btn_'.$counter.'" />';
                            echo '&nbsp; <input type="button" value="'.__('Remove Slide', 'premiumproperties').'" class="button button-primary button-large delete slider_system_remove_image_button" id="pm_slider_system_post_remove_btn_'.$counter.'" />';
							echo '</div>';
                            
                            $counter++;
                            
                        }
                        
                    } else {
                    
                        //Default value upon post initialization
                        echo '<b><i>'.__('No slides found','premiumproperties').'</i></b>';
                        
                    }                    
                
                ?>            
            
            </div>
            
            <br />
            <input type="button" id="pm-slider-system-add-new-slide-btn" class="button button-primary button-large" value="<?php _e('New Slide','premiumproperties') ?>">
        
        </div><!-- /.pm-featured-properties-settings-container -->
        
        
        
    
    <?php
	
}

function pm_properties_video_options_function($post) {

	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_enable_video_mode = get_post_meta( $post->ID, 'pm_enable_video_mode', true );
	$pm_featured_video_url = get_post_meta( $post->ID, 'pm_featured_video_url', true );
	
	?>
    
    	<p><?php _e('Enable Video?', 'premiumproperties') ?></p>
        
        <select id="pm_enable_video_mode" name="pm_enable_video_mode" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_enable_video_mode, 'no' ); ?>><?php _e('No', 'premiumproperties') ?></option>
            <option value="yes" <?php selected( $pm_enable_video_mode, 'yes' ); ?>><?php _e('Yes', 'premiumproperties') ?></option>
        </select>
        
        
        <?php if($pm_enable_video_mode === 'yes') { ?>
        	<div class="pm-featured-video-mode-settings-container visible" id="pm_featured_video_mode_settings_container">
        <?php } else { ?>
        	<div class="pm-featured-video-mode-settings-container hidden" id="pm_featured_video_mode_settings_container">
        <?php } ?>
        
        	<p><?php _e('Youtube Video ID', 'premiumproperties') ?></p>
        	<input type="text" value="<?php echo esc_html($pm_featured_video_url); ?>" name="pm_featured_video_url" class="pm-slider-system-upload-field" />
            <p><?php _e('<b>Enter a YouTube video ID</b> ex. XFPLSUZBCB8', 'premiumproperties') ?></p>
        
        </div>
        
     <?php
	
}

function pm_properties_thumb_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_thumb_image_meta = get_post_meta( $post->ID, 'pm_properties_thumb_image_meta', true );
	
	//echo $pm_properties_thumb_image_meta;
	
	//HTML code
	?>
    	<p><?php _e('Recommended size: 320x320px','premiumproperties'); ?></p>
		
        <input type="text" value="<?php echo esc_html($pm_properties_thumb_image_meta); ?>" name="pm_properties_thumb_image_meta" id="properties-thumb-img-uploader-field" class="pm-properties-thumb-admin-upload-field" />
                
		<input id="properties_thumb_upload_image_button" type="button" value="<?php _e('Media Library Image', 'premiumproperties'); ?>" class="button button-primary button-large" />
        
        <div class="pm-admin-upload-properties-thumb-preview"></div>
        
        <?php if($pm_properties_thumb_image_meta) : ?>
        	<input id="remove_properties_thumb_img_button" type="button" value="<?php _e('Remove Image', 'premiumproperties'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}

function pm_properties_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_image_meta = get_post_meta( $post->ID, 'pm_properties_image_meta', true );
	
	//HTML code
	?>
    	<p><?php _e('Recommended size: 1000x900px','premiumproperties'); ?></p>
        
        <input type="text" value="<?php echo esc_html($pm_properties_image_meta); ?>" name="pm_properties_image_meta" id="properties-image-uploader-field" class="pm-properties-image-admin-upload-field" />		
        
		<input id="properties_image_upload_button" type="button" value="<?php _e('Media Library Image', 'premiumproperties'); ?>" class="button button-primary button-large" />
        <div class="pm-admin-upload-properties-image-preview"></div>
        
        <?php if($pm_properties_image_meta) : ?>
        	<input id="remove_properties_img_button" type="button" value="<?php _e('Remove Image', 'premiumproperties'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}

function pm_properties_price_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_price_meta = get_post_meta( $post->ID, 'pm_properties_price_meta', true );
	//echo $pm_properties_thumb_image_meta;
	
	//HTML code
	?>
    	<p><?php _e('Enter a value for your property. <strong>NOTE:</strong> Insert a numeric value only - do not include any special characters such commas and dollar symbols.','premiumproperties'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_properties_price_meta); ?>" name="pm_properties_price_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_properties_size_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_size_meta = get_post_meta( $post->ID, 'pm_properties_size_meta', true );
	//echo $pm_properties_thumb_image_meta;
	
	//HTML code
	?>
    	<p><?php _e('Enter the size of your property','premiumproperties'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_properties_size_meta); ?>" name="pm_properties_size_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_properties_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_address_meta = get_post_meta( $post->ID, 'pm_properties_address_meta', true );
	$pm_properties_city_meta = get_post_meta( $post->ID, 'pm_properties_city_meta', true );
	$pm_properties_state_meta = get_post_meta( $post->ID, 'pm_properties_state_meta', true );
	$pm_properties_country_meta = get_post_meta( $post->ID, 'pm_properties_country_meta', true );
	$pm_properties_zip_meta = get_post_meta( $post->ID, 'pm_properties_zip_meta', true );
	$pm_properties_address_lat_meta = get_post_meta( $post->ID, 'pm_properties_address_lat_meta', true );
	$pm_properties_address_long_meta = get_post_meta( $post->ID, 'pm_properties_address_long_meta', true );
	
	//HTML code
	?>
    	<p><?php _e('Enter the address along with the latitude and longitude to activate the google map feature. You can use the','premiumproperties'); ?> <a href="http://www.latlong.net/" target="_blank">latlong.net</a> <?php _e('website to get your latitude and longitude co-ordinates','premiumproperties'); ?></p>
        
        <label for="pm_properties_address_meta"><?php _e('Street Address','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_address_meta); ?>" name="pm_properties_address_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_properties_city_meta"><?php _e('City','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_city_meta); ?>" name="pm_properties_city_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_properties_state_meta"><?php _e('State / Province','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_state_meta); ?>" name="pm_properties_state_meta" class="pm-admin-text-field" />
        
        <br><br>        
        
        <label for="pm_properties_country_meta"><?php _e('Country','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_country_meta); ?>" name="pm_properties_country_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_properties_zip_meta"><?php _e('Zip / Postal Code','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_zip_meta); ?>" name="pm_properties_zip_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_properties_address_lat_meta"><?php _e('Latitude','premiumproperties'); ?> <?php _e('(Required to activate the Google map)','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_address_lat_meta); ?>" name="pm_properties_address_lat_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_properties_address_long_meta"><?php _e('Longitude','premiumproperties'); ?> <?php _e('(Required to activate the Google map)','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_properties_address_long_meta); ?>" name="pm_properties_address_long_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_properties_summary_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_property_bedrooms_meta = get_post_meta( $post->ID, 'pm_property_bedrooms_meta', true );
	$pm_property_bathrooms_meta = get_post_meta( $post->ID, 'pm_property_bathrooms_meta', true );
	$pm_property_garages_meta = get_post_meta( $post->ID, 'pm_property_garages_meta', true );
	
	//HTML code
	?>
        
		<label for="pm_property_bedrooms_meta"><?php _e('Rooms (ex. 6+1 Rooms)','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_property_bedrooms_meta); ?>" name="pm_property_bedrooms_meta" class="pm-admin-text-field" />
        
        <label for="pm_property_bathrooms_meta"><?php _e('Bathrooms (ex. 4 Bathrooms)','premiumproperties'); ?> <?php _e('(Required to activate the Google map)','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_property_bathrooms_meta); ?>" name="pm_property_bathrooms_meta" class="pm-admin-text-field" />
        
        <label for="pm_property_garages_meta"><?php _e('Garages (ex. 3 Garages)','premiumproperties'); ?> <?php _e('(Required to activate the Google map)','premiumproperties'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_property_garages_meta); ?>" name="pm_property_garages_meta" class="pm-admin-text-field" />
        
            
    <?php
	
}


function pm_properties_amenities_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_amenities_meta = get_post_meta( $post->ID, 'pm_properties_amenities_meta', true );
	
	//Retrieve amentities
	$amentities_type_terms = get_terms( 'propertyamenitiestypes', array(
		'orderby'    => 'count',
		'hide_empty' => 0 // 0 = false (shows all categories even if unassigned)
	) );
	
	if( !empty($amentities_type_terms) ) {
		
		foreach ($amentities_type_terms as $term) { ?>

			<label class="pm-amenities-label"><?php echo $term->name; ?></label>
            
            <?php if(is_array($pm_properties_amenities_meta)) { ?>
            
            	<input type="checkbox" name="pm_properties_amenities_meta[]" value="<?php echo $term->name; ?>" <?php echo in_array($term->name, $pm_properties_amenities_meta) ? 'checked="checked"' : '' ?>>
            
            <?php } else { ?>
            
            	<input type="checkbox" name="pm_properties_amenities_meta[]" value="<?php echo $term->name; ?>">
            
            <?php } ?>			
		
		<?php }
		
	} else {
		
		echo esc_attr('No amenities found. You can use the Property Amenities section to add/remove amenities.', 'premiumproperties');
			
	}
	
	
}

function pm_assign_agent_meta_function($post) {

	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_assign_agent_meta = get_post_meta( $post->ID, 'pm_assign_agent_meta', true );
	
	//echo '$pm_assign_agent_meta = ' . $pm_assign_agent_metas;
		
	//Display the current assigned user
	$assigned_user_args = array(  
		'include' => array( intval($pm_assign_agent_meta) )
	);
	
	$assigned_user_query = new WP_User_Query($assigned_user_args);
	
	// User Loop
	if ( !empty( $assigned_user_query->results ) ) {
		
		foreach ( $assigned_user_query->results as $assigned_user ) {
			echo '<p><b>' . __('Currently assigned to:', 'premiumproperties') . '</b> ' . $assigned_user->display_name . ' </p>';
		}
		
	} else {
		//echo __('Currently not assigned to another Agent.', 'premiumproperties');
	}
	
	
	//Generate a list of registered users
	$args = array(  
		'role' => 'standard_member'
	);
	
	$user_query = new WP_User_Query($args);
	
	// User Loop
	if ( !empty( $user_query->results ) ) {
		
		echo '<select name="pm_assign_agent_meta">';
		
			if( $pm_assign_agent_meta === '' || $pm_assign_agent_meta === 'default' ){
				echo '<option value="default">' . __('-- Select an Agent --', 'premiumproperties') . '</option>';
			}
		
			foreach ( $user_query->results as $user ) {
				echo '<option value="'. $user->ID .'" '. selected( $pm_assign_agent_meta, $user->ID ) .'>' . $user->display_name . '</option>';
			}
		
		echo '</select>';
		
	} else {
		echo __('No agents found in database.', 'premiumproperties');
	}
	
}


function pm_properties_type_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$sale_type_terms = get_terms( 'propertysaletypes', array(
		'orderby'    => 'count',
		'hide_empty' => 0 // 0 = false (shows all categories even if unassigned)
	) );
	
	$payment_terms = get_terms( 'propertypaymentterms', array(
		'orderby'    => 'count',
		'hide_empty' => 0 // 0 = false (shows all categories even if unassigned)
	) );
	
	
	$pm_properties_type_meta = get_post_meta( $post->ID, 'pm_properties_type_meta', true );
	//echo '$pm_properties_type_meta = ' . $pm_properties_type_meta;
	
	$pm_properties_rental_type_meta = get_post_meta( $post->ID, 'pm_properties_rental_type_meta', true );
	//echo '$pm_properties_rental_type_meta = ' . $pm_properties_rental_type_meta;
	
	//HTML code
	?>
    	<p><?php _e('Set the sale type of your property','premiumproperties'); ?></p>
		
        <select id="pm_properties_type_select_meta" name="pm_properties_type_meta" class="pm-admin-select-list">  
        
        	<?php 
			
				foreach ($sale_type_terms as $term) { ?>
                
					<option value="<?php echo esc_attr($term->term_id) ?>" data-showpaymentterms="<?php echo trim($term->description) ?>" <?php selected( esc_attr($pm_properties_type_meta), $term->term_id ) ?>> <?php echo ucfirst($term->name) ?></option>	
                    
				<?php }
			
			?>
            
        </select>        
        
        <?php if( $pm_properties_rental_type_meta !== 'default' ) { ?>
        	<select id="pm_properties_rental_type_meta" name="pm_properties_rental_type_meta" class="pm-admin-select-list pm-properties-rental-type-container visible"> 
        <?php } else { ?>
        	<select id="pm_properties_rental_type_meta" name="pm_properties_rental_type_meta" class="pm-admin-select-list pm-properties-rental-type-container hidden"> 
        <?php } ?>
        
        		<option value="default">-- <?php esc_html_e('Payment Terms', 'premiumproperties') ?> --</option>  
             
             	<?php 
					 foreach ($payment_terms as $term) { ?>
						<option value="<?php echo esc_attr($term->name); ?>" <?php selected( esc_attr($pm_properties_rental_type_meta), $term->name ); ?>><?php echo ucfirst($term->name); ?></option>	
					 <?php }
				?>

            </select>
        	
    <?php
	
}

function pm_properties_featured_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_featured_meta = get_post_meta( $post->ID, 'pm_properties_featured_meta', true );
	//echo $pm_properties_featured_meta;
	
	//HTML code
	?>
    	<p><?php _e('Make this a featured Property? This option works in conjunction with the propertiesGallery shortcode.','premiumproperties'); ?></p>
		
        <select id="pm_properties_featured_meta" name="pm_properties_featured_meta" class="pm-admin-select-list">  
        	<option value="no" <?php selected( $pm_properties_featured_meta, 'no' ); ?>><?php _e('No', 'premiumproperties') ?></option>
            <option value="yes" <?php selected( $pm_properties_featured_meta, 'yes' ); ?>><?php _e('Yes', 'premiumproperties') ?></option>
        </select>


    <?php
	
}


function pm_properties_status_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_properties_status_meta = get_post_meta( $post->ID, 'pm_properties_status_meta', true );
	
	$status_type_terms = get_terms( 'propertystatustypes', array(
		'orderby'    => 'count',
		'hide_empty' => 0 // 0 = false (shows all categories even if unassigned)
	) );
	
	//HTML code
	?>
    	<p><?php _e('Set the status of your property','premiumproperties'); ?></p>
		
        <select id="pm_properties_status_meta" name="pm_properties_status_meta" class="pm-admin-select-list">  
        
        	<?php
				foreach ($status_type_terms as $term) { ?>
					<option value="<?php echo esc_attr($term->name); ?>" <?php selected( $pm_properties_status_meta, $term->name ) ?>><?php echo ucfirst($term->name) ?></option>
				<?php }
			 ?>
            
        </select>


    <?php
	
}



function pm_share_meta_function($post) {

	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_page_print_share_meta = get_post_meta( $post->ID, 'pm_page_print_share_meta', true );
	
	?>
            
        <select id="pm_page_print_share_meta" name="pm_page_print_share_meta" class="pm-admin-select-list"> 
        	<option value="on" <?php selected( $pm_page_print_share_meta, 'on' ); ?>><?php _e('ON', 'luxortheme') ?></option> 
            <option value="off" <?php selected( $pm_page_print_share_meta, 'off' ); ?>><?php _e('OFF', 'luxortheme') ?></option>
        </select>
    
    <?php
	
}


function pm_ln_save_inline_description( $term_id ) {
    
    $tax = get_taxonomy( 'propertysaletypes' );
    if ( current_filter() === "edited_propertysaletypes" && current_user_can( $tax->cap->edit_terms ) ) {
		
        $description = filter_input( INPUT_POST, 'description', FILTER_SANITIZE_STRING );
        // removing action to avoid recursion
        remove_action( current_filter(), __FUNCTION__ );
        wp_update_term( $term_id, 'propertysaletypes', array( 'description' => $description ) );
		
    }
}

//SAVE DATA
function pm_ln_add_properties_fields( $post_id, $post_type ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_type->post_type == 'post_properties' ) {
			
			// Store data in post meta table if present in post data	
			if(isset($_POST["pm_enable_slider_system"])){
				update_post_meta($post_id, "pm_enable_slider_system", sanitize_text_field($_POST["pm_enable_slider_system"]));
			}
			
			if(isset($_POST["pm_enable_fullscreen_mode"])){
				update_post_meta($post_id, "pm_enable_fullscreen_mode", sanitize_text_field($_POST["pm_enable_fullscreen_mode"]));
			}
					
			if(isset($_POST["pm_slider_system_post"])){
				
				$images = array();
				
				$counter = 0;
				
				foreach($_POST["pm_slider_system_post"] as $key => $text_field){
					
					if(!empty($text_field)){
						$images[$counter] = $text_field;
					}
					
					$counter++;
					
				}
							
				//$pm_slider_system_post = $_POST['pm_slider_system_post'];
				update_post_meta($post_id, "pm_properties_slides", $images);
				
			} else {
			
				$images = '';
			
				update_post_meta($post_id, "pm_properties_slides", $images);
				
			}
			
			if(isset($_POST["pm_enable_video_mode"])){
				update_post_meta($post_id, "pm_enable_video_mode", sanitize_text_field($_POST["pm_enable_video_mode"]));
			}
			
			if(isset($_POST["pm_featured_video_url"])){
				update_post_meta($post_id, "pm_featured_video_url", sanitize_text_field($_POST["pm_featured_video_url"]));
			}
			
			if(isset($_POST['pm_properties_thumb_image_meta'])){
				update_post_meta($post_id, "pm_properties_thumb_image_meta", sanitize_text_field($_POST['pm_properties_thumb_image_meta']));
			}
			
			if(isset($_POST['pm_header_image_meta'])){
				update_post_meta($post_id, "pm_header_image_meta", sanitize_text_field($_POST['pm_header_image_meta']));
			}
			
			if(isset($_POST['pm_properties_image_meta'])){
				update_post_meta($post_id, "pm_properties_image_meta", sanitize_text_field($_POST['pm_properties_image_meta']));
			}
			
			if(isset($_POST['pm_properties_status_meta'])){
				update_post_meta($post_id, "pm_properties_status_meta", sanitize_text_field($_POST['pm_properties_status_meta']));
			}
			
			if(isset($_POST['pm_properties_price_meta'])){
				update_post_meta($post_id, "pm_properties_price_meta", sanitize_text_field($_POST['pm_properties_price_meta']));
			}
			
			if(isset($_POST['pm_properties_type_meta'])){
				
				$val = intval($_POST['pm_properties_type_meta']);
				wp_set_object_terms( $post_id, $val, 'propertysaletypes');
				update_post_meta($post_id, "pm_properties_type_meta", $val);
			}
			
			if(isset($_POST['pm_properties_size_meta'])){
				update_post_meta($post_id, "pm_properties_size_meta", sanitize_text_field($_POST['pm_properties_size_meta']));
			}
			
			if(isset($_POST['pm_properties_address_meta'])){
				update_post_meta($post_id, "pm_properties_address_meta", sanitize_text_field($_POST['pm_properties_address_meta']));
			}
						
			if(isset($_POST['pm_properties_city_meta'])){
				update_post_meta($post_id, "pm_properties_city_meta", sanitize_text_field($_POST['pm_properties_city_meta']));
			}
			
			if(isset($_POST['pm_properties_state_meta'])){
				update_post_meta($post_id, "pm_properties_state_meta", sanitize_text_field($_POST['pm_properties_state_meta']));
			}
			
			if(isset($_POST['pm_properties_country_meta'])){
				update_post_meta($post_id, "pm_properties_country_meta", sanitize_text_field($_POST['pm_properties_country_meta']));
			}
			
			if(isset($_POST['pm_properties_zip_meta'])){
				update_post_meta($post_id, "pm_properties_zip_meta", sanitize_text_field($_POST['pm_properties_zip_meta']));
			}
			
			if(isset($_POST['pm_properties_address_lat_meta'])){
				update_post_meta($post_id, "pm_properties_address_lat_meta", sanitize_text_field($_POST['pm_properties_address_lat_meta']));
			}
			
			if(isset($_POST['pm_properties_address_long_meta'])){
				update_post_meta($post_id, "pm_properties_address_long_meta", sanitize_text_field($_POST['pm_properties_address_long_meta']));
			}
			
			if(isset($_POST['pm_properties_featured_meta'])){
				update_post_meta($post_id, "pm_properties_featured_meta", sanitize_text_field($_POST['pm_properties_featured_meta']));
			}
						
			if(isset($_POST['pm_property_bedrooms_meta'])){
				update_post_meta($post_id, "pm_property_bedrooms_meta", sanitize_text_field($_POST['pm_property_bedrooms_meta']));
			}
			
			if(isset($_POST['pm_property_bathrooms_meta'])){
				update_post_meta($post_id, "pm_property_bathrooms_meta", sanitize_text_field($_POST['pm_property_bathrooms_meta']));
			}
			
			if(isset($_POST['pm_property_garages_meta'])){
				update_post_meta($post_id, "pm_property_garages_meta", sanitize_text_field($_POST['pm_property_garages_meta']));
			}
						
			update_post_meta($post_id, "pm_properties_amenities_meta", $_POST['pm_properties_amenities_meta']);
			
			if(isset($_POST['pm_page_print_share_meta'])){
				update_post_meta($post_id, "pm_page_print_share_meta", sanitize_text_field($_POST['pm_page_print_share_meta']));
			}
			
			if(isset($_POST['pm_properties_rental_type_meta'])){
				update_post_meta($post_id, "pm_properties_rental_type_meta", sanitize_text_field($_POST['pm_properties_rental_type_meta']));
			}		
			
			if(isset($_POST['pm_assign_agent_meta'])){
				//Save a reference to the assigned author
				update_post_meta($post_id, "pm_assign_agent_meta", sanitize_text_field($_POST['pm_assign_agent_meta']));
			}
			
			//Update the post properties to assign a different user - this must be done outside of the post revision process
			if(isset($_POST['pm_assign_agent_meta'])){
				
				if( $_POST['pm_assign_agent_meta'] !== 'default' ) {// Check if an agent was selected before saving
					
					if ( !wp_is_post_revision( $post_id ) ){
	
						// unhook this function so it doesn't loop infinitely
						remove_action('save_post', 'pm_ln_add_properties_fields');
					
						// update the post, which calls save_post again
						$args = array('ID' => $post_id, 'post_author' => $_POST['pm_assign_agent_meta']);
						// update the post, which calls save_post again
						wp_update_post( $args );					
									
						// re-hook this function
						add_action('save_post', 'pm_ln_add_properties_fields');
					}
					
				}
				
			}			
			
		}
	
	endif;	
}

?>