(function($){

	$(document).ready(function(e) {
		
		
		if ( $( '#propertypaymenttermsdiv' ).length > 0 ) {
			$( '#propertypaymenttermsdiv' ).hide('fast');
		}
		
		if ( $( '#propertystatustypesdiv' ).length > 0 ) {
			$( '#propertystatustypesdiv' ).hide('fast');
		}
		
		if ( $( '#propertysaletypesdiv' ).length > 0 ) {
			$( '#propertysaletypesdiv' ).hide('fast');
		}
		
		if ( $( '#propertyamenitiestypesdiv' ).length > 0 ) {
			$( '#propertyamenitiestypesdiv' ).hide('fast');
		}		
				
		if(wp.media !== undefined){
			
			
			if( $('#pm_properties_header_upload_image_button').length > 0 ){
				
				var image_custom_uploader;
			
				//Page header image
				$('#pm_properties_header_upload_image_button').click(function(e) {
													
					 e.preventDefault();
		
					 //If the uploader object has already been created, reopen the dialog
					 if (image_custom_uploader) {
						 image_custom_uploader.open();
						 return;
					 }
					
				});
						
				 //Extend the wp.media object
				 image_custom_uploader = wp.media.frames.file_frame = wp.media({
					title: 'Choose Image',
					button: {
					text: 'Choose Image'
					},
					 multiple: false
				 });
				 
				 //When a file is selected, grab the URL and set it as the text field's value
				 image_custom_uploader.on('select', function() {
					 
					attachment = image_custom_uploader.state().get('selection').first().toJSON();
					var url = '';
					url = attachment['url'];
					
					$('#pm-properties-header-img-uploader-field').val(url);
					$('.pm-properties-header-image-preview').html('<img src="'+ url +'" />');
		
				 });
				
			}
			
			//properties thumb image
			 var properties_thumb_custom_uploader;
			 
			 $('#properties_thumb_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (properties_thumb_custom_uploader) {
					 properties_thumb_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 properties_thumb_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 properties_thumb_custom_uploader.on('select', function() {
				attachment = properties_thumb_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#properties-thumb-img-uploader-field').val(url);
				$('.pm-admin-upload-properties-thumb-preview').html('<img src="'+ url +'" />');
	
			 });
			 
			 
			 //properties image
			 var properties_image_custom_uploader;
			 
			 $('#properties_image_upload_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (properties_image_custom_uploader) {
					 properties_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 properties_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 properties_image_custom_uploader.on('select', function() {
				attachment = properties_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#properties-image-uploader-field').val(url);
				$('.pm-admin-upload-properties-image-preview').html('<img src="'+ url +'" />');
	
			 });
			
		}//end if
		
		
		//properties image preview
		if( $('.pm-properties-image-admin-upload-field').length > 0 ){
	
			var value = $('.pm-properties-image-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-properties-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//properties thumb image preview
		if( $('.pm-properties-thumb-admin-upload-field').length > 0 ){
	
			var value = $('.pm-properties-thumb-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-properties-thumb-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Header image image preview
		if( $('.pm-admin-properties-header-upload-field').length > 0 ){
	
			var value = $('.pm-admin-properties-header-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-properties-header-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		
		//Remove properties image button
		if( $('#remove_properties_img_button').length > 0 ){
	
			$('#remove_properties_img_button').click(function(e) {
								
				$('#properties-image-uploader-field').val('');
				$('.pm-admin-upload-properties-image-preview').empty();
				
			});
	
		}
		
		
		//Remove properties thumb image button
		if( $('#remove_properties_thumb_img_button').length > 0 ){
	
			$('#remove_properties_thumb_img_button').click(function(e) {
								
				$('#properties-thumb-img-uploader-field').val('');
				$('.pm-admin-upload-properties-thumb-preview').empty();
				
			});
	
		}
		
		//Remove properties header image button
		if( $('#remove_properties_header_img_button').length > 0 ){
	
			$('#remove_properties_header_img_button').click(function(e) {
								
				$('#pm-properties-header-img-uploader-field').val('');
				$('.pm-properties-header-image-preview').empty();
				
			});
	
		}
				
		
		//Check the sale type
		if( $('#pm_properties_type_select_meta').length > 0 ){
						
			$('#pm_properties_type_select_meta').change(function(e) {
				
				var val = $(this).find(':selected').data('showpaymentterms');
				//console.log('val = ' + val);
				
				//alert(val);
				
				if(val !== 'activate-payment-terms'){
					$('.pm-properties-rental-type-container').removeClass('visible').addClass('hidden');
					
					//Set the value to blank so we can reset the value
					$('#pm_properties_rental_type_meta').prop('selectedIndex',0);
					//$(this).find(':selected').val('');
						
				} else {
					$('.pm-properties-rental-type-container').removeClass('hidden').addClass('visible');		
				}
				
			});
			
		}//end if
		
				
		//Check if slider system is enabled or disabled
		if( $('#pm_enable_slider_system').length > 0 ){
						
			$('#pm_enable_slider_system').change(function(e) {
				var val = $(this).val();
				
				//console.log(val);
				
				if(val === 'yes'){
					$('.pm-featured-properties-settings-container').removeClass('hidden').addClass('visible');	
				} else {
					$('.pm-featured-properties-settings-container').removeClass('visible').addClass('hidden');		
				}
				
			});
			
		}
		
		
		
		//Check if video mode is enabled or disabled
		if( $('#pm_enable_video_mode').length > 0 ){
						
			$('#pm_enable_video_mode').change(function(e) {
				var val = $(this).val();
				
				if(val === 'yes'){
					$('.pm-featured-video-mode-settings-container').removeClass('hidden').addClass('visible');	
				} else {
					$('.pm-featured-video-mode-settings-container').removeClass('visible').addClass('hidden');		
				}
				
			});
			
		}
		
		//properties slide system
		if(wp.media !== undefined){
			
			//Global vars
			//var globalScope = 'test';
			
			var image_custom_uploader,
			target_text_field = '';
			
			//Target multiple image upload buttons
			if($('.slider_system_upload_image_button').length > 0) {
				
				methods.bindClickEvent();
									
			}
			
			//Featured projects properties system
			
			//Add New slide btn
			if( $('#pm-slider-system-add-new-slide-btn').length > 0 ){
			
				$('#pm-slider-system-add-new-slide-btn').click(function(e) {
					
					e.preventDefault();
					
					//Get counter value based on last input field in container
					if( $('#pm-featured-properties-images-container').find('.pm-slider-system-field-container:last-child').length > 0 ){
						var counterValue = $('.pm-slider-system-field-container:last-child').attr('id'),
						counterValueId = counterValue.substring(counterValue.lastIndexOf('_') + 1),
						counterValueIdFinal = ++counterValueId;
					} else {
						counterValueIdFinal = 0;
						$('#pm-featured-properties-images-container').html('');
					}
					
					//Append new slide field
					var wrapperStart = '<div class="pm-slider-system-field-container" id="pm_slider_system_field_container_'+counterValueIdFinal+'">';
					var field1 = '<input type="text" value="" name="pm_slider_system_post[]" id="pm_slider_system_post_'+counterValueIdFinal+'" class="pm-slider-system-upload-field" />';
					var field2 = '<input type="button" value="Media Library Image" class="button-secondary slider_system_upload_image_button" id="pm_slider_system_post_btn_'+counterValueIdFinal+'" />';
					var field3 = '&nbsp; <input type="button" value="Remove Slide" class="button button-primary button-large delete slider_system_remove_image_button" id="pm_slider_system_post_remove_btn_'+counterValueIdFinal+'" />';
					var wrapperEnd = '</div>';
					$('#pm-featured-properties-images-container').append(wrapperStart + field1 + field2 + field3 + wrapperEnd);
					
					methods.bindClickEvent();
					methods.bindRemoveImageClickEvent();
					
				});
				
			}
			
			if( $('.slider_system_remove_image_button').length > 0 ){
			
				methods.bindRemoveImageClickEvent();
				
			}
			
			
						
		}//end if
		
		
		
		
	
		
	});
	
	/* ==========================================================================
	   Methods
	   ========================================================================== */
		var methods = {
			
			bindClickEvent : function(e) {
							
				$('.slider_system_upload_image_button').click(function(e) {
					
					e.preventDefault();
					
					var btnId = $(this).attr('id'),
					targetTextFieldID = btnId.substring(btnId.lastIndexOf('_') + 1);
					
					
					//console.log(target_text_field.attr('id'));
	
					 //If the uploader object has already been created, reopen the media library window
					 if (image_custom_uploader) {
						 image_custom_uploader.open();
						 target_text_field = $('#pm_slider_system_post_'+targetTextFieldID)
						 return;
					 }
						
				});
				
				//Triggers the Media Library window
				image_custom_uploader = wp.media.frames.file_frame = wp.media({
					title: 'Choose Image',
					button: {
					text: 'Choose Image'
					},
					 multiple: false
				 });
				 
				 //When a file is selected, grab the URL and set it as the text field's value
				 image_custom_uploader.on('select', function() {
					 
					attachment = image_custom_uploader.state().get('selection').first().toJSON();
					var url = '';
					url = attachment['url'];
					
					//console.log(target_text_field.attr('id'));
					
					$(target_text_field).val(url);
					//$('.pm-admin-upload-field-preview').html('<img src="'+ url +'" />');
		
				 });
				
			},
			
			bindRemoveImageClickEvent : function(e) {
				
				$('.slider_system_remove_image_button').each(function(index, element) {
                    
					$(this).click(function(e) {
						
						e.preventDefault();
						
						var btnId = $(this).attr('id'),
						targetTextFieldID = btnId.substring(btnId.lastIndexOf('_') + 1);
						
						var targetTextFieldContainer = $('#pm_slider_system_field_container_'+targetTextFieldID).remove(),
						targetTextField = $('#pm_slider_system_post_'+targetTextFieldID).remove(),
						targetLibraryBtn = $('#pm_slider_system_post_btn_'+targetTextFieldID).remove();
						
						$(this).remove();
						
					});
					
                });
				
			},
			
		}

})(jQuery);