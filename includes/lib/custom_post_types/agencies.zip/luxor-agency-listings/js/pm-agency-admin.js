// JavaScript Document

(function($) {
	
	$(document).ready(function(e) {
		
		
		if(wp.media !== undefined){
			
			//agency header image
			 var agency_header_image_custom_uploader;
			 
			 $('#agency_header_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (agency_header_image_custom_uploader) {
					 agency_header_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 agency_header_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 agency_header_image_custom_uploader.on('select', function() {
				attachment = agency_header_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#pm-agency-header-img-uploader-field').val(url);
				$('.pm-agency-header-image-preview').html('<img src="'+ url +'" />');
	
			 });
			
			//agency image
			 var agency_image_custom_uploader;
			 
			 $('#agency_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (agency_image_custom_uploader) {
					 agency_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 agency_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 agency_image_custom_uploader.on('select', function() {
				attachment = agency_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#agency-img-uploader-field').val(url);
				$('.pm-admin-upload-agency-preview').html('<img src="'+ url +'" />');
	
			 });
			
		}//end if

		//Header image preview
		if( $('.pm-admin-agency-header-upload-field').length > 0 ){
	
			var value = $('.pm-admin-agency-header-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-agency-header-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//agency image preview
		if( $('.pm-agency-admin-upload-field').length > 0 ){
	
			var value = $('.pm-agency-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-agency-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Remove page header button
		if( $('#remove_agency_header_img_button').length > 0 ){
	
			$('#remove_agency_header_img_button').click(function(e) {
				
				$('#pm-agency-header-img-uploader-field').val('');
				$('.pm-agency-header-image-preview').empty();
				
			});
	
		}		

		//Remove agency image button
		if( $('#remove_agency_image_button').length > 0 ){
	
			$('#remove_agency_image_button').click(function(e) {
				
				$('#agency-img-uploader-field').val('');
				$('.pm-admin-upload-agency-preview').empty();
				
			});
	
		}

		
		//Datepicker
		if( $( "#datepicker" ).length > 0 ) {
			$( "#datepicker" ).datepicker();	
		}
		
    });
	
})(jQuery);