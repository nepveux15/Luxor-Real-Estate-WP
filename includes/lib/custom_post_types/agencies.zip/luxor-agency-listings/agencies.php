<?php 

/*
Plugin Name: Agencies Post Type for Luxor WordPress Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying agency profiles.
Version: 1.0.2
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'pm_ln_create_agencies_post_type');
//add_action('init', 'pm_ln_agency_titles');
add_action('admin_init', 'pm_ln_agencies_admin');
add_action('admin_enqueue_scripts', 'pm_load_agencies_admin_scripts');
add_action('save_post', 'pm_ln_add_agencies_fields', 10, 2);

add_action('admin_menu', 'pm_ln_add_agency_settings' );// ADD SETTINGS PAGE

//Translation support
add_action('plugins_loaded', 'pm_ln_agencies_load_textdomain');

function pm_ln_agencies_load_textdomain() { 
	load_plugin_textdomain( 'agenciesposttype', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function pm_ln_create_agencies_post_type() {
	
	$pm_agency_slug_name = get_option('pm_agency_slug_name');
	
    register_post_type( 'post_agencies',
        array(
            'labels' => array(
				'name' => __( 'Agencies', 'agenciesposttype' ),
				'singular_name' => __( 'Agencies', 'agenciesposttype' ),
				'add_new' => __( 'Add New Agency profile', 'agenciesposttype' ),
				'add_new_item' => __( 'Add New Agency profile', 'agenciesposttype' ),
				'edit' => __( 'Edit', 'agenciesposttype' ),
				'edit_item' => __( 'Edit Agency profile', 'agenciesposttype' ),
				'new_item' => __( 'New Agency profile', 'agenciesposttype' ),
				'view' => __( 'View', 'agenciesposttype' ),
				'view_item' => __( 'View Agency profile', 'agenciesposttype' ),
				'search_items' => __( 'Search Agency profiles', 'agenciesposttype' ),
				'not_found' => __( 'No Agency profiles found', 'agenciesposttype' ),
				'not_found_in_trash' => __( 'No Agency profiles found in Trash', 'agenciesposttype' ),
				'parent' => __( 'Parent Agency', 'agenciesposttype' )
			),
            'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => __( 'Easily lets you add new Agency profiles', 'agenciesposttype' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => !empty($pm_agency_slug_name) ? $pm_agency_slug_name : 'agency'),
			//'taxonomies' => array('category', 'post_tag')
			
        )
    );
	
}

//Add sub menus
function pm_ln_add_agency_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_agencies', esc_attr__('Agency Settings', 'agenciesposttype'),  esc_attr__('Agency Settings', 'agenciesposttype'), 'manage_options', 'agent_settings',  'pm_ln_agency_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}

//Settings page
function pm_ln_agency_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_agency_settings_update'])) {
		
		update_option('pm_agency_slug_name', sanitize_text_field($_POST["pm_agency_slug_name"]));
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'agenciesposttype').'</h4></div>';
		
	}//end of save data
	
	$pm_agency_slug_name = get_option('pm_agency_slug_name');
	
	?>
	
	<div class="wrap">
    
		<?php screen_icon(); ?>
        
		<h2><?php esc_attr_e('Agent Settings', 'agenciesposttype') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Agents Post Type plug-in below:', 'agenciesposttype') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_agency_settings_update" id="pm_agency_settings_update" value="true" />
            
            <label for="pm_agency_slug_name"><?php esc_attr_e('Agencies post type slug name', 'agenciesposttype') ?>:</label>
            
            <br><br>
            
            <input type="text" name="pm_agency_slug_name" id="pm_agency_slug_name" value="<?php esc_attr_e($pm_agency_slug_name); ?>" />
            
            <br><br>
            
			<div>
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'agenciesposttype'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}


function pm_load_agencies_admin_scripts() {

	wp_enqueue_script( 'pulsar-agencyjs', plugin_dir_url(__FILE__) . 'js/pm-agency-admin.js', array(), '1.0', true );
	wp_enqueue_style( 'pulsar-agency-styles', plugin_dir_url(__FILE__) . 'css/pm-agency-styles.css' );
	
}


function pm_ln_agencies_admin() {
	
	//Header Image
	add_meta_box( 
		'pm_header_image_meta', //ID
		__('Page Header Image', 'agenciesposttype'),  //label
		'pm_agencies_header_image_meta_function' , //function
		'post_agencies', //Post type
		'normal', 
		'high' 
	);
	
    //Agency Image
	add_meta_box( 
		'pm_agencies_logo_meta', //ID
		__('Agency Logo', 'agenciesposttype'),  //label
		'pm_agencies_logo_meta_function' , //function
		'post_agencies', //Post type
		'normal', 
		'high' 
	);

	//Phone number
	add_meta_box( 
		'pm_agencies_phone_meta', //ID
		__('Phone Number', 'agenciesposttype'),  //label
		'pm_agencies_phone_meta_function' , //function
		'post_agencies', //Post type
		'normal', 
		'high' 
	);

	
	//Email Address
	add_meta_box( 
		'pm_agencies_email_address_meta', //ID
		__('Agency Email Address', 'agenciesposttype'),  //label
		'pm_agencies_email_address_meta_function' , //function
		'post_agencies', //Post type
		'normal', 
		'high' 
	);
	
	//Agency Address
	add_meta_box( 
		'pm_agencies_address_meta', //ID
		'Address',  //label
		'pm_agencies_address_meta_function' , //function
		'post_agencies', //Post type
		'normal', 
		'high' 
	);
	
}


function pm_agencies_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_header_image_meta = get_post_meta( $post->ID, 'pm_header_image_meta', true );
	//echo $post->ID . $pm_woocom_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px or 1920x800px for parallax mode','agenciesposttype'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_header_image_meta); ?>" name="pm_header_image_meta" id="pm-agency-header-img-uploader-field" class="pm-admin-agency-header-upload-field" />
		<input id="agency_header_upload_image_button" type="button" value="<?php _e('Media Library Image', 'agenciesposttype'); ?>" class="button button-primary button-large" />
        <div class="pm-agency-header-image-preview"></div>
        
        <?php if($pm_header_image_meta) : ?>
        	<input id="remove_agency_header_img_button" type="button" value="<?php _e('Remove Image', 'agenciesposttype'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}


function pm_agencies_logo_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agencies_logo_meta = get_post_meta( $post->ID, 'pm_agencies_logo_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agencies_logo_meta); ?>" name="pm_agencies_logo_meta" id="agency-img-uploader-field" class="pm-agency-admin-upload-field" />
		<input id="agency_upload_image_button" type="button" value="<?php _e('Media Library Image', 'agenciesposttype'); ?>" class="button button-primary button-large" />
        <div class="pm-admin-upload-agency-preview"></div>
        
        <?php if($pm_agencies_logo_meta) : ?>
        	<input id="remove_agency_image_button" type="button" value="<?php _e('Remove Image', 'agenciesposttype'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}



function pm_agencies_phone_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agencies_phone_meta = get_post_meta( $post->ID, 'pm_agencies_phone_meta', true );
	//echo $pm_agencies_email_address_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agencies_phone_meta); ?>" name="pm_agencies_phone_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agencies_email_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agencies_email_address_meta = get_post_meta( $post->ID, 'pm_agencies_email_address_meta', true );
	//echo $pm_agencies_email_address_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agencies_email_address_meta); ?>" name="pm_agencies_email_address_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_agencies_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_agencies_address_meta = get_post_meta( $post->ID, 'pm_agencies_address_meta', true );
	$pm_agencies_state_meta = get_post_meta( $post->ID, 'pm_agencies_state_meta', true );
	$pm_agencies_country_meta = get_post_meta( $post->ID, 'pm_agencies_country_meta', true );
	$pm_agencies_zip_meta = get_post_meta( $post->ID, 'pm_agencies_zip_meta', true );
	$pm_agencies_address_lat_meta = get_post_meta( $post->ID, 'pm_agencies_address_lat_meta', true );
	$pm_agencies_address_long_meta = get_post_meta( $post->ID, 'pm_agencies_address_long_meta', true );
	
	//HTML code
	?>
    	<p><?php _e('Enter the address along with the latitude and longitude to activate the google map feature. You can use the','agenciesposttype'); ?> <a href="http://www.latlong.net/" target="_blank">latlong.net</a> <?php _e('website to get your latitude and longitude co-ordinates','agenciesposttype'); ?></p>
        
        <label for="pm_agencies_address_meta"><?php _e('Street Address','agenciesposttype'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_agencies_address_meta); ?>" name="pm_agencies_address_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_agencies_state_meta"><?php _e('State / Province','agenciesposttype'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_agencies_state_meta); ?>" name="pm_agencies_state_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_agencies_country_meta"><?php _e('Country','agenciesposttype'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_agencies_country_meta); ?>" name="pm_agencies_country_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_agencies_zip_meta"><?php _e('Zip / Postal Code','agenciesposttype'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_agencies_zip_meta); ?>" name="pm_agencies_zip_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_agencies_address_lat_meta"><?php _e('Latitude','agenciesposttype'); ?> <?php _e('(Required for Google map activation)','agenciesposttype'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_agencies_address_lat_meta); ?>" name="pm_agencies_address_lat_meta" class="pm-admin-text-field" />
        
        <br><br>
        
        <label for="pm_agencies_address_long_meta"><?php _e('Longitude','agenciesposttype'); ?> <?php _e('(Required for Google map activation)','agenciesposttype'); ?></label>
		<input type="text" value="<?php echo esc_html($pm_agencies_address_long_meta); ?>" name="pm_agencies_address_long_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_ln_add_agencies_fields( $post_id, $post_type ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_type->post_type == 'post_agencies' ) {
			
			// Store data in post meta table if present in post data		
			if(isset($_POST['pm_header_image_meta'])){
				update_post_meta($post_id, "pm_header_image_meta", sanitize_text_field($_POST['pm_header_image_meta']));
			}
			
			if(isset($_POST['pm_agencies_logo_meta'])){
				update_post_meta($post_id, "pm_agencies_logo_meta", sanitize_text_field($_POST['pm_agencies_logo_meta']));
			}
			
			if(isset($_POST['pm_agencies_phone_meta'])){
				update_post_meta($post_id, "pm_agencies_phone_meta", sanitize_text_field($_POST['pm_agencies_phone_meta']));
			}
			
						
			if(isset($_POST['pm_agencies_email_address_meta'])){
				update_post_meta($post_id, "pm_agencies_email_address_meta", sanitize_text_field($_POST['pm_agencies_email_address_meta']));
			}
			
			
			if(isset($_POST['pm_agencies_address_meta'])){
				update_post_meta($post_id, "pm_agencies_address_meta", sanitize_text_field($_POST['pm_agencies_address_meta']));
			}
			
			if(isset($_POST['pm_agencies_state_meta'])){
				update_post_meta($post_id, "pm_agencies_state_meta", sanitize_text_field($_POST['pm_agencies_state_meta']));
			}
			
			if(isset($_POST['pm_agencies_country_meta'])){
				update_post_meta($post_id, "pm_agencies_country_meta", sanitize_text_field($_POST['pm_agencies_country_meta']));
			}
			
			if(isset($_POST['pm_agencies_zip_meta'])){
				update_post_meta($post_id, "pm_agencies_zip_meta", sanitize_text_field($_POST['pm_agencies_zip_meta']));
			}
			
			if(isset($_POST['pm_agencies_address_lat_meta'])){
				update_post_meta($post_id, "pm_agencies_address_lat_meta", sanitize_text_field($_POST['pm_agencies_address_lat_meta']));
			}
			
			if(isset($_POST['pm_agencies_address_long_meta'])){
				update_post_meta($post_id, "pm_agencies_address_long_meta", sanitize_text_field($_POST['pm_agencies_address_long_meta']));
			}
			
				
		}
	
	endif;	
}

?>