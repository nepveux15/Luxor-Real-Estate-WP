// JavaScript Document

(function($) {
	
	$(document).ready(function(e) {
		
		
		if(wp.media !== undefined){
			
			//agent header image
			 var agent_header_image_custom_uploader;
			 
			 $('#agent_header_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (agent_header_image_custom_uploader) {
					 agent_header_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 agent_header_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 agent_header_image_custom_uploader.on('select', function() {
				attachment = agent_header_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#pm-agent-header-img-uploader-field').val(url);
				$('.pm-agent-header-image-preview').html('<img src="'+ url +'" />');
	
			 });
			
			//agent image
			 var agent_image_custom_uploader;
			 
			 $('#agent_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (agent_image_custom_uploader) {
					 agent_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 agent_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 agent_image_custom_uploader.on('select', function() {
				attachment = agent_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#agent-img-uploader-field').val(url);
				$('.pm-admin-upload-agent-preview').html('<img src="'+ url +'" />');
	
			 });
			
		}//end if

		//Header image preview
		if( $('.pm-admin-agent-header-upload-field').length > 0 ){
	
			var value = $('.pm-admin-agent-header-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-agent-header-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//agent image preview
		if( $('.pm-agent-admin-upload-field').length > 0 ){
	
			var value = $('.pm-agent-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-agent-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Remove page header button
		if( $('#remove_agent_header_img_button').length > 0 ){
	
			$('#remove_agent_header_img_button').click(function(e) {
				
				$('#pm-agent-header-img-uploader-field').val('');
				$('.pm-agent-header-image-preview').empty();
				
			});
	
		}		

		//Remove agent image button
		if( $('#remove_agent_image_button').length > 0 ){
	
			$('#remove_agent_image_button').click(function(e) {
				
				$('#agent-img-uploader-field').val('');
				$('.pm-admin-upload-agent-preview').empty();
				
			});
	
		}

		
		//Datepicker
		if( $( "#datepicker" ).length > 0 ) {
			$( "#datepicker" ).datepicker();	
		}
		
    });
	
})(jQuery);