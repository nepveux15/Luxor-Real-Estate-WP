<?php 

/*
Plugin Name: Agents Post Type for Luxor WordPress Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying agent profiles.
Version: 1.0.4
Author: Micro Themes
Author URI: http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'pm_ln_create_agent_post_type');
//add_action('init', 'pm_ln_agent_titles');
add_action('admin_init', 'pm_ln_agent_admin');
add_action('admin_enqueue_scripts', 'pm_load_agent_admin_scripts');
add_action('save_post', 'pm_ln_add_agent_fields', 10, 2);

add_action('admin_menu', 'pm_ln_add_agent_settings' );// ADD SETTINGS PAGE

//Translation support
add_action('plugins_loaded', 'pm_ln_agents_load_textdomain');


/**** FUNCTIONS **********************************************************************************************/


//Add sub menus
function pm_ln_add_agent_settings() {

	//create custom top-level menu
	//add_menu_page( 'Pulsar Framework Documentation', 'Theme Documentation', 'manage_options', __FILE__, 'pm_documentation_main_page',	plugins_url( '/images/wp-icon.png', __FILE__ ) );
	
	//create sub-menu items
	add_submenu_page( 'edit.php?post_type=post_agents', esc_attr__('Agent Settings', 'agentsposttype'),  esc_attr__('Agent Settings', 'agentsposttype'), 'manage_options', 'agent_settings',  'pm_ln_agent_settings_page' );
	
	//create an options page under Settings tab
	//add_options_page('My API Plugin', 'My API Plugin', 'manage_options', 'pm_myplugin', 'pm_myplugin_option_page');	
}

//Settings page
function pm_ln_agent_settings_page() {
		
	//Save data first
	if (isset($_POST['pm_agent_settings_update'])) {
		
		update_option('pm_agent_profile_btn_text_meta', (string)$_POST["pm_agent_profile_btn_text_meta"]);
		update_option('pm_agents_slug_name', sanitize_text_field($_POST["pm_agents_slug_name"]));
		
		echo '<div id="message" class="updated fade"><h4>'.esc_attr__('Your settings have been saved.', 'agentsposttype').'</h4></div>';
		
	}//end of save data
	
	$pm_agent_profile_btn_text_meta = get_option('pm_agent_profile_btn_text_meta');
	$pm_agents_slug_name = get_option('pm_agents_slug_name');
	
	?>
	
	<div class="wrap">
    
		<?php screen_icon(); ?>
        
		<h2><?php esc_attr_e('Agent Settings', 'agentsposttype') ?></h2>
		
		<h4><?php esc_attr_e('Configure the settings for the Agents Post Type plug-in below:', 'agentsposttype') ?></h4>
		
		<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		
			<input type="hidden" name="pm_agent_settings_update" id="pm_agent_settings_update" value="true" />
            
            <label for="pm_agents_slug_name"><?php esc_attr_e('Agents post type slug name', 'agentsposttype') ?>:</label>
            
            <br><br>
            
            <input type="text" name="pm_agents_slug_name" id="pm_agents_slug_name" value="<?php esc_attr_e($pm_agents_slug_name); ?>" />
            
            <br><br>
			
            <label for="pm_agent_profile_btn_text_meta"><?php esc_attr_e('Agent post button text', 'agentsposttype') ?></label>
            
            <br><br>
            	
			<input type="text" name="pm_agent_profile_btn_text_meta" value="<?php echo esc_attr($pm_agent_profile_btn_text_meta); ?>">
			
            <br><br>       
            
			<div>
				<input type="submit" name="pm_settings_update" class="button button-primary button-large" value="<?php esc_attr_e('Update Settings', 'agentsposttype'); ?> &raquo;" />
			</div>
		
		</form>
		
	</div>
	
	<?php
	
}


function pm_ln_agents_load_textdomain() { 
	load_plugin_textdomain( 'agentsposttype', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function pm_ln_create_agent_post_type() {
	
	$pm_agents_slug_name = get_option('pm_agents_slug_name');
	
    register_post_type( 'post_agents',
        array(
            'labels' => array(
				'name' => __( 'Agents', 'agentsposttype' ),
				'singular_name' => __( 'Agents', 'agentsposttype' ),
				'add_new' => __( 'Add New Agent profile', 'agentsposttype' ),
				'add_new_item' => __( 'Add New Agent profile', 'agentsposttype' ),
				'edit' => __( 'Edit', 'agentsposttype' ),
				'edit_item' => __( 'Edit Agent profile', 'agentsposttype' ),
				'new_item' => __( 'New Agent profile', 'agentsposttype' ),
				'view' => __( 'View', 'agentsposttype' ),
				'view_item' => __( 'View Agent profile', 'agentsposttype' ),
				'search_items' => __( 'Search Agent profiles', 'agentsposttype' ),
				'not_found' => __( 'No Agent profiles found', 'agentsposttype' ),
				'not_found_in_trash' => __( 'No Agent profiles found in Trash', 'agentsposttype' ),
				'parent' => __( 'Parent Agent', 'agentsposttype' )
			),
            'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => __( 'Easily lets you add new Agent profiles', 'agentsposttype' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => !empty($pm_agents_slug_name) ? $pm_agents_slug_name : 'agent'),
			//'taxonomies' => array('category', 'post_tag')
			
        )
    );
	flush_rewrite_rules();
	
}


function pm_load_agent_admin_scripts() {

	wp_enqueue_script( 'pulsar-agentsjs', plugin_dir_url(__FILE__) . 'js/pm-agents-admin.js', array(), '1.0', true );
	wp_enqueue_style( 'pulsar-agents-styles', plugin_dir_url(__FILE__) . 'css/pm-agents-styles.css' );
	
}


function pm_ln_agent_admin() {
	
	//Header Image
	add_meta_box( 
		'pm_header_image_meta', //ID
		__('Page Header Image', 'agentsposttype'),  //label
		'pm_agent_header_image_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
    //Agent Image
	add_meta_box( 
		'pm_agent_image_meta', //ID
		__('Agent Profile Image', 'agentsposttype'),  //label
		'pm_agent_image_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Agent Account ID
	add_meta_box( 
		'pm_agent_account_id_meta', //ID
		__('Agent Account ID', 'agentsposttype'),  //label
		'pm_agent_account_id_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Agent Stat 1
	add_meta_box( 
		'pm_agent_stat1_meta', //ID
		__('Agent Stat 1', 'agentsposttype'),  //label
		'pm_agent_stat1_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Agent Stat 2
	add_meta_box( 
		'pm_agent_stat2_meta', //ID
		__('Agent Stat 2', 'agentsposttype'),  //label
		'pm_agent_stat2_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Twitter Address
	add_meta_box( 
		'pm_agent_twitter_meta', //ID
		__('Twitter Address', 'agentsposttype'),  //label
		'pm_agent_twitter_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Facebook Address
	add_meta_box( 
		'pm_agent_facebook_meta', //ID
		__('Facebook Address', 'agentsposttype'),  //label
		'pm_agent_facebook_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Google Plus Address
	add_meta_box( 
		'pm_agent_gplus_meta', //ID
		__('Google Plus Address', 'agentsposttype'),  //label
		'pm_agent_gplus_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Linkedin Address
	add_meta_box( 
		'pm_agent_linkedin_meta', //ID
		__('Linkedin Address', 'agentsposttype'),  //label
		'pm_agent_linkedin_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Email Address
	add_meta_box( 
		'pm_agent_email_address_meta', //ID
		__('Email Address', 'agentsposttype'),  //label
		'pm_agent_email_address_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Mobile phone
	add_meta_box( 
		'pm_agent_mobile_phone_meta', //ID
		__('Mobile Phone Number', 'agentsposttype'),  //label
		'pm_agent_mobile_phone_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Business phone
	add_meta_box( 
		'pm_agent_business_phone_meta', //ID
		__('Business Phone Number', 'agentsposttype'),  //label
		'pm_agent_business_phone_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Skype
	add_meta_box( 
		'pm_agent_skype_meta', //ID
		__('Skype Name', 'agentsposttype'),  //label
		'pm_agent_skype_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Specialties
	add_meta_box( 
		'pm_agent_specialties_meta', //ID
		__('Specialties', 'agentsposttype'),  //label
		'pm_agent_specialties_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
	//Contact Form
	add_meta_box( 
		'pm_agent_contact_form_meta', //ID
		__('Enable contact form?', 'agentsposttype'),  //label
		'pm_agent_contact_form_meta_function' , //function
		'post_agents', //Post type
		'normal', 
		'high' 
	);
	
}


function pm_agent_contact_form_meta_function($post) {

	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_agent_contact_form_meta = get_post_meta( $post->ID, 'pm_agent_contact_form_meta', true );
	
	?>
            
        <select id="pm_agent_contact_form_meta" name="pm_agent_contact_form_meta" class="pm-admin-select-list"> 
        	<option value="on" <?php selected( $pm_agent_contact_form_meta, 'on' ); ?>><?php _e('ON', 'luxortheme') ?></option> 
            <option value="off" <?php selected( $pm_agent_contact_form_meta, 'off' ); ?>><?php _e('OFF', 'luxortheme') ?></option>
        </select>
    
    <?php
	
}

function pm_agent_specialties_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_agent_specialties_meta = get_post_meta( $post->ID, 'pm_agent_specialties_meta', true );
	
	//HTML code
	?>
    	<p><?php _e('Provide a comma seperated list of specialties.'); ?></p>
        
		<textarea name="pm_agent_specialties_meta" class="pm-textarea"><?php echo esc_attr($pm_agent_specialties_meta); ?></textarea>
        
            
    <?php
	
}


function pm_agent_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_header_image_meta = get_post_meta( $post->ID, 'pm_header_image_meta', true );
	//echo $post->ID . $pm_woocom_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px or 1920x800px for parallax mode','agentsposttype'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_header_image_meta); ?>" name="pm_header_image_meta" id="pm-agent-header-img-uploader-field" class="pm-admin-agent-header-upload-field" />
		<input id="agent_header_upload_image_button" type="button" value="<?php _e('Media Library Image', 'agentsposttype'); ?>" class="button button-primary button-large" />
        <div class="pm-agent-header-image-preview"></div>
        
        <?php if($pm_header_image_meta) : ?>
        	<input id="remove_agent_header_img_button" type="button" value="<?php _e('Remove Image', 'agentsposttype'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}

function pm_agent_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_image_meta = get_post_meta( $post->ID, 'pm_agent_image_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_image_meta); ?>" name="pm_agent_image_meta" id="agent-img-uploader-field" class="pm-agent-admin-upload-field" />
		<input id="agent_upload_image_button" type="button" value="<?php _e('Media Library Image', 'agentsposttype'); ?>" class="button button-primary button-large" />
        <div class="pm-admin-upload-agent-preview"></div>
        
        <?php if($pm_agent_image_meta) : ?>
        	<input id="remove_agent_image_button" type="button" value="<?php _e('Remove Image', 'agentsposttype'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}



function pm_agent_account_id_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_account_id_meta = get_post_meta( $post->ID, 'pm_agent_account_id_meta', true );
	//echo $pm_agent_account_id_meta;
		

	//HTML code
	?>
    	<p><?php _e('If applicable, enter the account ID number associated with this Agent profile. This will be used to fetch recent properties.', 'agentsposttype'); ?></p>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_account_id_meta); ?>" name="pm_agent_account_id_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_agent_stat1_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_stat1_meta = get_post_meta( $post->ID, 'pm_agent_stat1_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_stat1_meta); ?>" name="pm_agent_stat1_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_stat2_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_stat2_meta = get_post_meta( $post->ID, 'pm_agent_stat2_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_stat2_meta); ?>" name="pm_agent_stat2_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_message_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_message_meta = get_post_meta( $post->ID, 'pm_agent_message_meta', true );
	//echo $pm_agent_message_meta;
		

	//HTML code
	?>
        
		<input type="text" value="<?php echo esc_attr($pm_agent_message_meta); ?>" name="pm_agent_message_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_twitter_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_twitter_meta = get_post_meta( $post->ID, 'pm_agent_twitter_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_agent_twitter_meta); ?>" name="pm_agent_twitter_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_facebook_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_facebook_meta = get_post_meta( $post->ID, 'pm_agent_facebook_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_agent_facebook_meta); ?>" name="pm_agent_facebook_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_gplus_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_gplus_meta = get_post_meta( $post->ID, 'pm_agent_gplus_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_agent_gplus_meta); ?>" name="pm_agent_gplus_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_linkedin_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_linkedin_meta = get_post_meta( $post->ID, 'pm_agent_linkedin_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_agent_linkedin_meta); ?>" name="pm_agent_linkedin_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_agent_email_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_email_address_meta = get_post_meta( $post->ID, 'pm_agent_email_address_meta', true );
	//echo $pm_agent_email_address_meta;
		

	//HTML code
	?>
    
    	<p><?php _e('<strong>NOTE:</strong> This email address will also be used for the Contact Form.','agentsposttype'); ?></p>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_email_address_meta); ?>" name="pm_agent_email_address_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_agent_mobile_phone_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_mobile_phone_meta = get_post_meta( $post->ID, 'pm_agent_mobile_phone_meta', true );
	//echo $pm_agent_email_address_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_mobile_phone_meta); ?>" name="pm_agent_mobile_phone_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_agent_business_phone_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_business_phone_meta = get_post_meta( $post->ID, 'pm_agent_business_phone_meta', true );
	//echo $pm_agent_business_phone_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_business_phone_meta); ?>" name="pm_agent_business_phone_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_agent_skype_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_agent_skype_meta = get_post_meta( $post->ID, 'pm_agent_skype_meta', true );
	//echo $pm_agent_skype_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_agent_skype_meta); ?>" name="pm_agent_skype_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_ln_add_agent_fields( $post_id, $post_type ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_type->post_type == 'post_agents' ) {
			
			// Store data in post meta table if present in post data			
			//Check for agent values
			if(isset($_POST['pm_header_image_meta'])){
				update_post_meta($post_id, "pm_header_image_meta", sanitize_text_field($_POST['pm_header_image_meta']));
			}
			
			if(isset($_POST['pm_agent_image_meta'])){
				update_post_meta($post_id, "pm_agent_image_meta", sanitize_text_field($_POST['pm_agent_image_meta']));
			}
			
			if(isset($_POST['pm_agent_stat1_meta'])){
				update_post_meta($post_id, "pm_agent_stat1_meta", sanitize_text_field($_POST['pm_agent_stat1_meta']));
			}
			
			if(isset($_POST['pm_agent_stat2_meta'])){
				update_post_meta($post_id, "pm_agent_stat2_meta", sanitize_text_field($_POST['pm_agent_stat2_meta']));
			}
			
			if(isset($_POST['pm_agent_message_meta'])){
				update_post_meta($post_id, "pm_agent_message_meta", sanitize_text_field($_POST['pm_agent_message_meta']));
			}
			
			if(isset($_POST['pm_agent_twitter_meta'])){
				update_post_meta($post_id, "pm_agent_twitter_meta", sanitize_text_field($_POST['pm_agent_twitter_meta']));
			}
			
			if(isset($_POST['pm_agent_facebook_meta'])){
				update_post_meta($post_id, "pm_agent_facebook_meta", sanitize_text_field($_POST['pm_agent_facebook_meta']));
			}
			
			if(isset($_POST['pm_agent_gplus_meta'])){
				update_post_meta($post_id, "pm_agent_gplus_meta", sanitize_text_field($_POST['pm_agent_gplus_meta']));
			}
			
			if(isset($_POST['pm_agent_linkedin_meta'])){
				update_post_meta($post_id, "pm_agent_linkedin_meta", sanitize_text_field($_POST['pm_agent_linkedin_meta']));
			}
			
			if(isset($_POST['pm_agent_email_address_meta'])){
				update_post_meta($post_id, "pm_agent_email_address_meta", sanitize_text_field($_POST['pm_agent_email_address_meta']));
			}
			
			if(isset($_POST['pm_agent_specialties_meta'])){
				update_post_meta($post_id, "pm_agent_specialties_meta", sanitize_text_field($_POST['pm_agent_specialties_meta']));
			}
			
			if(isset($_POST['pm_agent_contact_form_meta'])){
				update_post_meta($post_id, "pm_agent_contact_form_meta", sanitize_text_field($_POST['pm_agent_contact_form_meta']));
			}			
			
			if(isset($_POST['pm_agent_business_phone_meta'])){
				update_post_meta($post_id, "pm_agent_business_phone_meta", sanitize_text_field($_POST['pm_agent_business_phone_meta']));
			}
			
			if(isset($_POST['pm_agent_mobile_phone_meta'])){
				update_post_meta($post_id, "pm_agent_mobile_phone_meta", sanitize_text_field($_POST['pm_agent_mobile_phone_meta']));
			}
			
			if(isset($_POST['pm_agent_skype_meta'])){
				update_post_meta($post_id, "pm_agent_skype_meta", sanitize_text_field($_POST['pm_agent_skype_meta']));
			}
			
			if(isset($_POST['pm_agent_account_id_meta'])){
				update_post_meta($post_id, "pm_agent_account_id_meta", sanitize_text_field($_POST['pm_agent_account_id_meta']));
			}
			
				
		}
	
	endif;	
}

?>